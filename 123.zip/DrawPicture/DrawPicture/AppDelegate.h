//
//  AppDelegate.h
//  DrawPicture
//
//  Created by admin on 16/11/24.
//  Copyright © 2016年 voquan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

