//
//  ViewController.m
//  DrawPicture
//
//  Created by admin on 16/11/24.
//  Copyright © 2016年 voquan. All rights reserved.
//

#import "ViewController.h"
#import "DrawChart.h"


@interface ViewController ()

@property(nonatomic, strong)DrawChart *drawView;//画图的view
@property(nonatomic, strong)NSArray *x_arr;//x轴数据数组
@property(nonatomic, strong)NSArray *y_arr;//y轴数据数组

@end


#define zzWidth    [UIScreen mainScreen].bounds.size.width
#define zzHeight   [UIScreen mainScreen].bounds.size.height
@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view addSubview:self.drawView];
    
    [self.drawView drawZheXianTu:self.x_arr and:self.y_arr];
    
    
    [self initSelBtn];
    
}

- (void)initSelBtn{
    
    NSArray *arr = @[@"柱状图", @"饼状图", @"折线图"];
    
    for (int i=0; i<3; i++) {
        
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        
        btn.frame = CGRectMake(30+i*((zzWidth-60)/4 + (zzWidth-60)/8), 100, (zzWidth-60)/4, 30);
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        btn.backgroundColor = [UIColor redColor];
        [btn setTitle:arr[i] forState:UIControlStateNormal];
        btn.tag = 100+i;
        [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        
        [self.view addSubview:btn];
    }

}


- (NSArray *)x_arr{
    
    if (!_x_arr) {
        
        _x_arr = @[@"北京", @"上海", @"广州", @"深圳", @"武汉", @"成都", @"南京"];
        
    }
    
    return _x_arr;
}


- (NSArray *)y_arr{
    
    if (!_y_arr) {
        
        _y_arr = @[@"80", @"70", @"90", @"60", @"40", @"30", @"60"];
    }
    
    return _y_arr;
}




- (DrawChart *)drawView{
    
    if (!_drawView) {
        
        _drawView = [[DrawChart alloc] init];
        _drawView.frame = CGRectMake(0, 200, zzWidth, zzWidth);
//        _drawView.backgroundColor = [UIColor redColor];
    }
    
    return _drawView;
}



- (void)btnClick:(UIButton *)btn{

    if (btn.tag == 100) {
        
        [self.drawView drawZhuZhuangTu:self.x_arr and:self.y_arr];
        
        
    }else if (btn.tag == 101){
        
        [self.drawView drawBingZhuangTu:self.x_arr and:self.y_arr];
        
    }else{
        
        [self.drawView drawZheXianTu:self.x_arr and:self.y_arr];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
